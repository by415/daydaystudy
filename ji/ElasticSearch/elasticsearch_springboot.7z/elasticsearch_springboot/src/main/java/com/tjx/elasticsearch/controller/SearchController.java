package com.tjx.elasticsearch.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class SearchController {


}
